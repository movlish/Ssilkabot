from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
import logging
import re
import os
import asyncio
import phonenumbers
from phonenumbers import geocoder, carrier
from aiogram import Bot, Dispatcher, types
from aiogram.types import BotCommand
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from sqlalchemy import Column, Integer, String, select
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker, declarative_base
from dotenv import load_dotenv
from aiogram.filters import Command

# Load environment variables
load_dotenv()

# Get values from environment
API_TOKEN = os.getenv('API_TOKEN')
ADMIN_IDS = list(map(int, os.getenv('ADMIN_IDS').split(',')))  # Process list of IDs
DATABASE_URL = os.getenv('SQLALCHEMY_URL')

# Set up logging
logging.basicConfig(level=logging.INFO)

# Create the model and database
Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, unique=True)
    user_name = Column(String)

# Create a database connection
engine = create_async_engine(DATABASE_URL, echo=True)
AsyncSessionLocal = sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)

# Create tables
async def init_db():
    async with engine.begin() as conn:
        logging.info("Creating tables...")
        await conn.run_sync(Base.metadata.create_all)
        logging.info("Tables created successfully.")

# Assuming this function queries your database to get user profile details based on phone number
async def get_user_profile_by_phone_number(session: AsyncSession, phone_number: str):
    # Replace this with actual logic to query the database
    async with session.begin():
        stmt = select(User).filter(User.user_name == phone_number)
        result = await session.execute(stmt)
        user = result.scalars().first()
        return user

# Initialize database
asyncio.run(init_db())

# Initialize bot and dispatcher
bot = Bot(token=API_TOKEN)
dp = Dispatcher(storage=MemoryStorage())

# Set commands
async def set_commands(bot: Bot):
    commands = [
        BotCommand(command="start", description="Start the bot"),
        BotCommand(command="admin", description="Admin panel"),
        BotCommand(command="id", description="Get your ID"),
        BotCommand(command="shnq", description="Shaharsozlik normalari va qoidalari"),
        BotCommand(command="infotashkilot", description="Tashkilotlar haqida ma'lumot")
    ]
    await bot.set_my_commands(commands)
# /id yuborganda foydalanuvchining id sini chiqaradi
@dp.message(Command("id"))
async def cmd_start(message: types.Message):
    await message.answer(f'{message.from_user.id}')
    # /id yuborganda foydalanuvchining id sini chiqaradi
    
@dp.message(Command("infotashkilot"))
async def cmd_start(message: types.Message):
    reyting_url = f"https://reyting.mc.uz/new-ratings?type=0&page=1"
    orginfo_url = f"https://orginfo.uz/uz/search/all"
    soliq_url = f"https://soliq.uz/activities/debtor"

    await message.reply(
        # f"Xatolik: Telefon raqami noto'g'ri. Lekin raqamda 9 ta raqam bor.\n"
        f"Mana STIRni qidirish uchun havolalar:\n"
        f"*Tashkilot reytingi haqida*📊 [Reyting]({reyting_url})\n"
        f"*Tashkilot haqida ma'lumot*📋 [Orginfo.uz]({orginfo_url})\n"
        f"*Soliq qarzini tekshirish*🏢 [Soliq.uz]({soliq_url})",
        parse_mode='Markdown'
    )
    
# /shnq
@dp.message(Command("shnq"))
async def cmd_start(message: types.Message):
    shnq_url = f"https://mc.uz/oz/documents/shaharsozlik-normalari-va-qoidalari"
    shnq1_url = f"https://mc.uz/oz/activity/smeta-resurs-normalari"
    shnq2_url = f"https://mc.uz/oz/documents/texnik-reglamentlar"
    shnq3_url = f"https://mc.uz/oz/documents/malumotnoma"
    shnq4_url = f"https://mc.uz/oz/documents/qurilish-normalari-proekt"
    shnq5_url = f"https://mc.uz/oz/documents/metodik-qollanmalar-va-tavsiyalar"
    shnq6_url = f"https://mc.uz/oz/documents/qurilish-va-uy-joy-kommunal-xojaligi-vazirligining-qarorlari"
    shnq7_url = f"https://mc.uz/oz/documents/vazirlar-mahkamasi-qaror-va-farmoyishlari"
    shnq8_url = f"https://mc.uz/oz/documents/prezident-qonunlari-va-farmonlari"
    shnq9_url = f"https://mc.uz/oz/documents/qonunlar"
    shnq10_url = f"https://mc.uz/oz/documents/konstitutsiyaning-mazmun-mohiyati"
    shnq11_url = f"https://mc.uz/oz/activity/ekspertiza-duk"
    shnq12_url = f"https://mc.uz/oz/activity/davxizmat"
    shnq13_url = f"https://mc.uz/oz/activity/zilzilabardosh"

    await message.reply(
                    f"1.[Shaharsozlik normalari va qoidalari]({shnq_url})\n"
                    f"2.[Smeta-resurs normalari]({shnq1_url})\n"
                    f"3.[Qurilish reglamentlar]({shnq2_url})\n"
                    f"4.[Ma'lumotnoma]({shnq3_url})\n"
                    f"5.[Qurilish normalari (proekt)]({shnq4_url})\n"
                    f"6.[Metodik qo’llanmalar va tavsiyalar]({shnq5_url})\n"
                    f"7.[Vazirlikning Qaror va qo'shma qarorlari]({shnq6_url})\n"
                    f"8.[Vazirlar Mahkamasi qaror va farmoyishlari]({shnq7_url})\n"
                    f"9.[Prezident qonunlari va farmonlari]({shnq8_url})\n"
                    f"10.[Qonunlar]({shnq9_url})\n"
                    f"11.[Konstitutsiyaning mazmun-mohiyati]({shnq10_url})\n"
                    f"12.[Shaharsozlik hujjatlari ekspertizasi” DUK haqida]({shnq11_url})\n"
                    f"13.[Davlat xizmatlari]({shnq12_url})\n"
                    f"14.[Zilzilabardosh]({shnq13_url})",
                    parse_mode='Markdown'
                    )


# Function to format phone number
def format_phone_number(phone_number: str) -> str:
    cleaned_number = re.sub(r'\D', '', phone_number)  # Remove non-numeric characters
    if len(cleaned_number) == 9:  # If the number consists of 9 digits
        cleaned_number = f'+998{cleaned_number}'  # Add country code for Uzbekistan
    elif len(cleaned_number) == 9 and not cleaned_number.startswith('992'):
        cleaned_number = f'+992{cleaned_number}'  # Tajikistan (+992)
    elif len(cleaned_number) == 9 and not cleaned_number.startswith('993'):
        cleaned_number = f'+993{cleaned_number}'  # Turkmenistan (+993)
    elif len(cleaned_number) == 9 and not cleaned_number.startswith('994'):
        cleaned_number = f'+994{cleaned_number}'  # Azerbaijan (+994)
    elif len(cleaned_number) == 9 and not cleaned_number.startswith('995'):
        cleaned_number = f'+995{cleaned_number}'  # Georgia (+995)
    elif len(cleaned_number) == 9 and not cleaned_number.startswith('996'):
        cleaned_number = f'+996{cleaned_number}'  # Kyrgyzstan (+996)
    elif len(cleaned_number) == 9 and not cleaned_number.startswith('374'):
        cleaned_number = f'+374{cleaned_number}'  # Armenia (+374)
    elif len(cleaned_number) == 9 and not cleaned_number.startswith('373'):
        cleaned_number = f'+373{cleaned_number}'  # Moldova (+373)
    # elif len(cleaned_number) == 9 and not cleaned_number.startswith('375'):
    #     cleaned_number = f'+375{cleaned_number}'  # Belarus (+375)
    # elif len(cleaned_number) == 10 and not cleaned_number.startswith('90'):
    #     cleaned_number = f'+90{cleaned_number}'#Turkiye (+90)
    # elif len(cleaned_number) == 10 and not cleaned_number.startswith('7'):
    #     cleaned_number = f'+7{cleaned_number}'#Kazakhstan (+7)
    elif not cleaned_number.startswith('+'):  # If it doesn't start with +
        cleaned_number = f'+{cleaned_number}'
    return cleaned_number

# Function to generate search URLs
def generate_search_urls(phone_number: str):
    query = f"{phone_number}"
    google_url = f"https://www.google.com/search?q={query}"
    yandex_url = f"https://yandex.com/search/?text={query}"
    youtube_url = f"https://www.youtube.com/results?search_query={query}"
    orginfo_url = f"https://orginfo.uz/uz/search/all/?q={query}" 
    reyting_url = f"https://reyting.mc.uz/new-ratings?type=0&page=1&stir={query}" 
    gov_uz_url = f"https://my.gov.uz/oz/service/all-services?ServiceFilterForm%5Ball_title%5D={query}" 
    soliq_url = f"https://soliq.uz/activities/debtor"
    return google_url, yandex_url, youtube_url, orginfo_url, reyting_url, gov_uz_url, soliq_url

# Function to generate Telegram link
def generate_telegram_link(phone_number: str) -> str:
    return f"https://t.me/{phone_number}"

# Function to generate WhatsApp link
def generate_whatsapp_link(phone_number: str) -> str:
    return f"https://wa.me/{phone_number}"

logging.info(f"ADMIN_IDS: {ADMIN_IDS}")

# Function for sending admin notifications
async def notify_admins(message: str):
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(admin_id, message)
            logging.info(f"Message sent to admin {admin_id}")
        except Exception as e:
            logging.error(f"Failed to send message to admin {admin_id}: {e}")

# Handler for the /start command
@dp.message(Command("start"))
async def send_welcome(message: types.Message):
    user_id = message.from_user.id
    user_name = message.from_user.full_name
    username = message.from_user.username

    # Create Telegram profile link for the user
    if username:
        user_link = f'<a href="https://t.me/{username}">{user_name}</a>'
    else:
        user_link = f'{user_name} (Username отсутствует)'

    async with AsyncSessionLocal() as session:
        async with session.begin():
            result = await session.execute(select(User).filter(User.user_id == user_id))
            existing_user = result.scalars().first()

            if not existing_user:
                new_user = User(user_id=user_id, user_name=user_name)
                session.add(new_user)
                await session.commit()

            # Count total users
            result = await session.execute(select(User.id))
            user_count = len(result.scalars().all())

    # Notify admin about new user
    await notify_admins(
        f"User {user_link} (ID: {user_id}) started the bot. Total users: {user_count}"
    )

    # Reply to the user
    if user_id in ADMIN_IDS:
        await message.answer("Salom, administrator! Barcha foydalanuvchilarga xabar yuborish uchun /admin buyrug‘idan foydalaning.")
    else:
        await message.answer("Salom! Menga istalgan telefon raqamingizni yuboring va men Telegram va WhatsAppga havolalar yarataman. Shuningdek, tashkilotning STIRini yoki tashkilot nomini yuborishingiz mumkin. Men ularni qidirish uchun havola yuboraman. Ushbu saytlarga Orginfo.uz Reyting.mc.uz My.gov.uz Google Youtube Yandex")

# Функция для отправки сообщений всем пользователям
async def broadcast_message(content: str):
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(User.user_id))
        user_ids = result.scalars().all()
        # user_ids = [row[0] for row in result.fetchall()]

    if not user_ids:
        logging.warning("Xabarni yuboradigan foydalanuvchilar yo'q.")
        return

    logging.info(f"Topilgan {len(user_ids)} foydalanuvchilar. Biz xabar jo'natishni boshlaymiz.")

    async def send_message(user_id):
        try:
            await bot.send_message(user_id, content)
            logging.info(f"Foydalanuvchiga yuborilgan xabar {user_id}")
        except Exception as e:
            logging.error(f"Foydalanuvchiga xabar yuborib bo'lmadi {user_id}: {str(e)}")

    await asyncio.gather(*[send_message(user_id) for user_id in user_ids])

    logging.info("Xabar barcha foydalanuvchilarga yuborildi.")

class AdminStates(StatesGroup):
    waiting_for_message = State()

@dp.message(Command("admin"))
async def admin_command_handler(message: types.Message):
    if message.from_user.id in ADMIN_IDS:
        async with AsyncSessionLocal() as session:
            result = await session.execute(select(User.user_id))
            user_ids = result.scalars().all()
            # user_ids = [row[0] for row in result.fetchall()]

        await message.answer(f"Barcha foydalanuvchilarga yubormoqchi bo'lgan xabarni kiriting. Foydalanuvchilar soni: {len(user_ids)}")
        await AdminStates.waiting_for_message.set()  # Устанавливаем состояние ожидания сообщения
    else:
        await message.answer("Admin bilan aloqa @movlish13 \n tel:+998977261308,  +998881221312")

@dp.message(AdminStates.waiting_for_message)
async def handle_admin_message(message: types.Message, state: FSMContext):
    if message.from_user.id in ADMIN_IDS:
        content = message.text.strip()

        if content:
            await broadcast_message(content)
            await message.answer("Xabar barcha foydalanuvchilarga yuborildi.")
        else:
            await message.answer("Xabar bo'sh bo'lishi mumkin emas.")

        await state.clear()  # Yuborilgandan keyin holatni tozalang
    else:
        await message.answer("Admin bilan aloqa @movlish13 \n tel: +998977261308,  +998881221312")
        await state.clear()  # Agar kimdir etarli darajada foydalanmasa
        
        
# Telefon raqamini qayta ishlash funksiyasi
async def handle_phone_input(message: types.Message):
    phone_number = message.text.strip()

    # Format the phone number
    formatted_phone_number = format_phone_number(phone_number)
    logging.info(f"Received phone number: {phone_number}")
    logging.info(f"Formatted phone number: {formatted_phone_number}")

    # Raqamni tozalaymiz (faqat raqamlarni qoldiramiz)
    cleaned_number = re.sub(r'\D', '', phone_number)
    
    # Initialize the async session and fetch the user profile based on phone number
    async with AsyncSessionLocal() as session:
        profile = await get_user_profile_by_phone_number(session, cleaned_number)
        
    if profile:
        user_full_name = profile.get('full_name', 'Topilmadi')
        username = profile.get('username', 'Topilmadi')
        birth_year = profile.get('birth_year', 'Topilmadi')
    else:
        user_full_name = 'Topilmadi'
        username = 'Topilmadi'
        birth_year = 'Topilmadi'

    try:
        # Handle phone numbers that are exactly 9 digits long
        if len(cleaned_number) == 9:
            phone_number_obj = phonenumbers.parse(formatted_phone_number)
            country = geocoder.description_for_number(phone_number_obj, "en")
            operator = carrier.name_for_number(phone_number_obj, "en")
            # Add specific country codes to the phone number
            formatted_uzbekistan = f'+998{cleaned_number}'
            formatted_tajikistan = f'+992{cleaned_number}'
            formatted_kyrgyzstan = f'+996{cleaned_number}'
            formatted_azerbaijan = f'+994{cleaned_number}'
            formatted_Georgia = f'+995{cleaned_number}'
            formatted_Turkmenistan = f'+993{cleaned_number}'
            formatted_Armenia = f'+374{cleaned_number}'
            formatted_Moldova = f'+373{cleaned_number}'
            # formatted_Belarus = f'+375{cleaned_number}'
            # formatted_Turkiye = f'+90{cleaned_number}'
            # formatted_Kazakhstan = f'+7{cleaned_number}'

            # Generate links for all countries
            telegram_uzb = generate_telegram_link(formatted_uzbekistan)
            whatsapp_uzb = generate_whatsapp_link(formatted_uzbekistan)
            
            telegram_geo = generate_telegram_link(formatted_Georgia)
            whatsapp_geo = generate_whatsapp_link(formatted_Georgia)

            telegram_tkm = generate_telegram_link(formatted_Turkmenistan)
            whatsapp_tkm = generate_whatsapp_link(formatted_Turkmenistan)

            telegram_taj = generate_telegram_link(formatted_tajikistan)
            whatsapp_taj = generate_whatsapp_link(formatted_tajikistan)

            telegram_kyr = generate_telegram_link(formatted_kyrgyzstan)
            whatsapp_kyr = generate_whatsapp_link(formatted_kyrgyzstan)

            telegram_aze = generate_telegram_link(formatted_azerbaijan)
            whatsapp_aze = generate_whatsapp_link(formatted_azerbaijan)
            
            telegram_arm = generate_telegram_link(formatted_Armenia)
            whatsapp_arm = generate_whatsapp_link(formatted_Armenia)

            telegram_mol = generate_telegram_link(formatted_Moldova)
            whatsapp_mol = generate_whatsapp_link(formatted_Moldova)
            
            # telegram_blr = generate_telegram_link(formatted_Belarus)
            # whatsapp_blr = generate_whatsapp_link(formatted_Belarus)
            
            # telegram_tur = generate_telegram_link(formatted_Turkiye)
            # whatsapp_tur = generate_whatsapp_link(formatted_Turkiye)
            
            telegram_tkm = generate_telegram_link(formatted_Turkmenistan)
            whatsapp_tkm = generate_whatsapp_link(formatted_Turkmenistan)
            
            # telegram_kaz = generate_telegram_link(formatted_Kazakhstan)
            # whatsapp_kaz = generate_whatsapp_link(formatted_Kazakhstan)

            # Construct the response with inline links
            response = (
                f"📞Telefon: {formatted_uzbekistan}\n"
                f"🌍 Davlat: {country}\n"
                f"📡 Operator: {operator}\n"
                # f"👤 Foydalanuvchi: {user_full_name}\n"
                # f"💬 Username: @{username}\n"
                # f"🎂 Tug'ilgan yil: {birth_year}\n"
                f"[ Telegram Uzb ]({telegram_uzb}) | "  # Highlight Uzbekistan's links
                f"[ WhatsApp Uzb ]({whatsapp_uzb})\n\n"
                f"[Telegram Taj]({telegram_taj}) | "
                f"[WhatsApp Taj]({whatsapp_taj})\n"
                f"[Telegram Kyr]({telegram_kyr}) | "
                f"[WhatsApp Kyr]({whatsapp_kyr})\n"
                f"[Telegram Aze]({telegram_aze}) | "
                f"[WhatsApp Aze]({whatsapp_aze})\n"
                # f"[Telegram Tur]({telegram_tur}) | "
                # f"[WhatsApp Tur]({whatsapp_tur})\n"
                f"[Telegram Tkm]({telegram_tkm}) | "
                f"[WhatsApp Tkm]({whatsapp_tkm})\n"
                f"[Telegram Mol]({telegram_mol}) | "
                f"[WhatsApp Mol]({whatsapp_mol})\n"
                f"[Telegram Arm]({telegram_arm}) | "
                f"[WhatsApp Arm]({whatsapp_arm})\n"
                f"[Telegram Geo]({telegram_geo}) | "
                f"[WhatsApp Geo]({whatsapp_geo})\n"
                # f"[Telegram Blr]({telegram_blr}) | "
                # f"[WhatsApp Blr]({whatsapp_blr})\n"
                # f"[Telegram Kaz]({telegram_kaz}) | "
                # f"[WhatsApp Kaz]({whatsapp_kaz})\n"
            )

            await message.reply(response, parse_mode='Markdown')

        else:
            # For other phone numbers (non-9 digits), use phonenumbers to parse and validate
            phone_number_obj = phonenumbers.parse(formatted_phone_number)
            country = geocoder.description_for_number(phone_number_obj, "en")
            operator = carrier.name_for_number(phone_number_obj, "en")

            telegram_link = generate_telegram_link(formatted_phone_number)
            whatsapp_link = generate_whatsapp_link(formatted_phone_number)

            response = (
                f"📞Telefon: {formatted_phone_number}\n"
                f"🌍 Davlat: {country}\n"
                f"📡 Operator: {operator}\n"
                f"👤 Foydalanuvchi: {user_full_name}\n"
                f"💬 Username: @{username}\n"
                f"🎂 Tug'ilgan yil: {birth_year}\n"
                f"[Telegram]({telegram_link}) |"
                f"[WhatsApp]({whatsapp_link})"
            )

            await message.reply(response, parse_mode='Markdown')

    except phonenumbers.NumberParseException as e:
        logging.info(f"Cleaned number for parsing: {cleaned_number}")  # Log cleaned number
        await notify_admins(f"Foydalanuvchidan raqamni ajratish xatosi {message.from_user.id}: {str(e)}")
        logging.error(f"Tahlil qilish xatosi: {e}")

    except ValueError as e:
        await message.reply(f"Xatolik: {str(e)}")
        await notify_admins(f"Foydalanuvchi raqamini tasdiqlash xatosi {message.from_user.id}: {str(e)}")

    except Exception as e:
        await message.reply(f"Xatolik: {str(e)}")
        await notify_admins(f"Foydalanuvchidan umumiy xato {message.from_user.id}: {str(e)}")



# User messages handler
@dp.message()
async def on_user_message(message: types.Message):
    if message.content_type in [types.ContentType.TEXT]:
        await handle_phone_input(message)

# Start the bot
async def main():
    try:
        await set_commands(bot)
        await dp.start_polling(bot)
    finally:
        await bot.session.close()

if __name__ == '__main__':
    asyncio.run(main())
